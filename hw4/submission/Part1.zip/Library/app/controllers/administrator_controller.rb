class AdministratorController < ApplicationController
    def index
    end
  end
  